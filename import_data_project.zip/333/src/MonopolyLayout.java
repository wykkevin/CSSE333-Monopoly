import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class MonopolyLayout {

	public static void load(String name) throws IOException {

		File inputFile = new File(name);
		Scanner inScanner1 = new Scanner(inputFile);

		Scanner inScanner = new Scanner(inputFile);

		for (int y = 0; y < inputFile.length(); y++) {
			if (inScanner.hasNext()) {
				String line = inScanner.nextLine();

			}
		}

	}

	public static Connection getConnection() throws Exception {
		String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url = "jdbc:sqlserver://golem.csse.rose-hulman.edu;databaseName=1-7 Monopoly;"
				+ "user=liuz6;password={LzsLzs985165439}";

		Class.forName(driver);
		Connection conn = DriverManager.getConnection(url);
		return conn;
	}

	public static void main(String args[]) throws SQLException, IOException {

		Connection conn = null;

		try {

			conn = getConnection();
			conn.setAutoCommit(false);
			Statement st = conn.createStatement();

			System.out.println("Enter File name");
			Scanner scanner = new Scanner(System.in);

			while (true) {
				String commandLine = scanner.nextLine();
				try {
					load(commandLine);
					File inputFile = new File(commandLine);

					System.out.println("input table name");

					Scanner txtScanner = new Scanner(System.in);
					String tableName = txtScanner.nextLine();

					Scanner inScanner = new Scanner(inputFile);

					for (int y = 0; y < inputFile.length(); y++) {
						if (inScanner.hasNext()) {
							String line = inScanner.nextLine();
							if (commandLine.equals("Layout.txt") || commandLine.equals("Map.txt")) {
								st.executeUpdate("INSERT INTO " + tableName + " VALUES " + "(" + line + ")");
							} else if (commandLine.equals("Card.txt")) {
								st.executeUpdate("SET IDENTITY_INSERT Card ON"
										+ " INSERT INTO Card(CardID,Name,EffectMoney,EffectUserID) " + "VALUES " + "("
										+ line + ")" + " SET IDENTITY_INSERT Card OFF");
							}

						}
					}

					conn.commit();
					System.out.println("Input Succeed");
				} catch (IOException exception) {
					exception.printStackTrace();
				}
			}

		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
			e.printStackTrace();
		} finally {
			conn.close();
			System.out.println("input succeed!");
		}

	}
}
